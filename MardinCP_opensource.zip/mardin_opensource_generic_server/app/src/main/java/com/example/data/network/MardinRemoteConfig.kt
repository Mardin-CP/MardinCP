package com.example.data.network

/**
 * Centralized remote configuration endpoints.
 *
 * Configure the server host/base URL and endpoint paths below.
 * Example: https://your-domain.example/api/
 */
object MardinRemoteConfig {
    // Enter your public server base URL here. Keep the URL ending with "/".
    const val SERVER_BASE_URL = ""

    const val CONFIG_PATH = "config.json"
    const val STATS_PATH = "stats.json"
    const val UPDATE_PATH = "update.json"

    val URL_LIST: String get() = buildUrl(CONFIG_PATH)
    val URL_STATS: String get() = buildUrl(STATS_PATH)
    val URL_UPDATE: String get() = buildUrl(UPDATE_PATH)

    private fun buildUrl(path: String): String {
        val base = SERVER_BASE_URL.trim()
        if (base.isBlank()) return ""
        return base.trimEnd('/') + "/" + path.trimStart('/')
    }
}
