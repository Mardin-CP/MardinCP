package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mardin_config_prefs")

class ConfigDataStore(private val context: Context) {

    companion object {
        val KEY_CACHED_JSON = stringPreferencesKey("cached_config_json")
        val KEY_LAST_UPDATE_TIME = stringPreferencesKey("last_update_timestamp")
        val KEY_THEME_MODE = stringPreferencesKey("app_theme_mode")
        val KEY_CACHED_INSTALL_COUNT = longPreferencesKey("cached_install_count")
        val KEY_APP_LANGUAGE = stringPreferencesKey("app_language")
        val KEY_APPLIED_DATA_REVISION = stringPreferencesKey("applied_data_revision")
        val KEY_APPLIED_PROXIES_REVISION = stringPreferencesKey("applied_proxies_revision")
        val KEY_APPLIED_CONFIGS_REVISION = stringPreferencesKey("applied_configs_revision")
    }

    val cachedJsonFlow: Flow<String?> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[KEY_CACHED_JSON]
        }

    val lastUpdateTimeFlow: Flow<String?> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[KEY_LAST_UPDATE_TIME]
        }

    val themeModeFlow: Flow<String> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[KEY_THEME_MODE] ?: "SYSTEM"
        }

    val cachedInstallCountFlow: Flow<Long?> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[KEY_CACHED_INSTALL_COUNT]
        }

    val appLanguageFlow: Flow<String> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[KEY_APP_LANGUAGE] ?: "en"
        }

    /**
     * Reads cached config JSON and timestamp in a single atomic preference snapshot,
     * avoiding multiple separate flow collections on startup.
     */
    suspend fun getCachedConfigSnapshot(): Pair<String?, String?> {
        return try {
            val prefs = context.dataStore.data.first()
            prefs[KEY_CACHED_JSON] to prefs[KEY_LAST_UPDATE_TIME]
        } catch (_: Exception) {
            null to null
        }
    }

    suspend fun saveCachedConfig(json: String, lastUpdate: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_CACHED_JSON] = json
            preferences[KEY_LAST_UPDATE_TIME] = lastUpdate
        }
    }

    suspend fun saveCachedInstallCount(count: Long) {
        context.dataStore.edit { preferences ->
            preferences[KEY_CACHED_INSTALL_COUNT] = count
        }
    }

    suspend fun saveThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_THEME_MODE] = mode
        }
    }

    suspend fun saveAppLanguage(languageCode: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_APP_LANGUAGE] = languageCode
        }
    }

    suspend fun getAppliedDataRevisions(): Triple<String?, String?, String?> {
        return try {
            val prefs = context.dataStore.data.first()
            Triple(
                prefs[KEY_APPLIED_DATA_REVISION],
                prefs[KEY_APPLIED_PROXIES_REVISION],
                prefs[KEY_APPLIED_CONFIGS_REVISION]
            )
        } catch (_: Exception) {
            Triple(null, null, null)
        }
    }

    suspend fun saveAppliedDataRevisions(dataRev: String, proxiesRev: String, configsRev: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_APPLIED_DATA_REVISION] = dataRev
            preferences[KEY_APPLIED_PROXIES_REVISION] = proxiesRev
            preferences[KEY_APPLIED_CONFIGS_REVISION] = configsRev
        }
    }

    suspend fun clearCache() {
        context.dataStore.edit { preferences ->
            preferences.remove(KEY_CACHED_JSON)
            preferences.remove(KEY_LAST_UPDATE_TIME)
        }
    }
}
