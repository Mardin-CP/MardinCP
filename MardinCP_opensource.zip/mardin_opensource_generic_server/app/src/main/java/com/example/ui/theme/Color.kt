package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val PrimaryBlueLight = Color(0xFF0284C7)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFE0F2FE)
val OnPrimaryContainerLight = Color(0xFF0369A1)

val SecondaryBlueLight = Color(0xFF3B82F6)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFDBEAFE)
val OnSecondaryContainerLight = Color(0xFF1E40AF)

val TertiaryLight = Color(0xFF0D9488)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFCCFBF1)
val OnTertiaryContainerLight = Color(0xFF115E59)

val BackgroundLight = Color(0xFFF8FAFC)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Colors
val PrimaryBlueDark = Color(0xFF38BDF8)
val OnPrimaryDark = Color(0xFF082F49)
val PrimaryContainerDark = Color(0xFF075985)
val OnPrimaryContainerDark = Color(0xFFE0F2FE)

val SecondaryBlueDark = Color(0xFF60A5FA)
val OnSecondaryDark = Color(0xFF172554)
val SecondaryContainerDark = Color(0xFF1E3A8A)
val OnSecondaryContainerDark = Color(0xFFDBEAFE)

val TertiaryDark = Color(0xFF2DD4BF)
val OnTertiaryDark = Color(0xFF134E4A)
val TertiaryContainerDark = Color(0xFF115E59)
val OnTertiaryContainerDark = Color(0xFFCCFBF1)

val BackgroundDark = Color(0xFF0B132B)
val OnBackgroundDark = Color(0xFFF1F5F9)
val SurfaceDark = Color(0xFF131E3A)
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF1C2A4E)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF2E4069)

// Status & Protocol Accent Colors
val StatusAvailable = Color(0xFF10B981)
val StatusAvailableContainer = Color(0xFFD1FAE5)
val StatusAvailableDarkContainer = Color(0xFF064E3B)

val StatusUnavailable = Color(0xFFEF4444)
val StatusUnavailableContainer = Color(0xFFFEE2E2)
val StatusUnavailableDarkContainer = Color(0xFF7F1D1D)

val ProtocolMTProto = Color(0xFF0284C7)
val ProtocolVLESS = Color(0xFF8B5CF6)
val ProtocolVMess = Color(0xFFEC4899)
val ProtocolTrojan = Color(0xFFF59E0B)
val ProtocolShadowsocks = Color(0xFF10B981)
val ProtocolOther = Color(0xFF64748B)
