package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class RemoteConfigResponse(
    @Json(name = "app_name") val appName: String? = null,
    @Json(name = "last_update") val lastUpdate: String? = null,
    @Json(name = "version") val version: String? = null,
    @Json(name = "revision") val revision: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "telegram_proxies") val telegramProxies: List<TelegramProxyDto>? = null,
    @Json(name = "configs") val configs: List<CustomConfigDto>? = null
)

enum class DataUpdateType {
    CONFIGS_ONLY,
    PROXIES_ONLY,
    BOTH
}

@JsonClass(generateAdapter = true)
data class TelegramProxyDto(
    @Json(name = "name") val name: String? = null,
    @Json(name = "country") val country: String? = null,
    @Json(name = "type") val type: String? = null,
    @Json(name = "link") val link: String? = null,
    @Json(name = "update_info") val updateInfo: String? = null,
    @Json(name = "recommended") val recommended: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class CustomConfigDto(
    @Json(name = "name") val name: String? = null,
    @Json(name = "country") val country: String? = null,
    @Json(name = "type") val type: String? = null,
    @Json(name = "link") val link: String? = null,
    @Json(name = "config") val config: String? = null,
    @Json(name = "update_info") val updateInfo: String? = null,
    @Json(name = "recommended") val recommended: Boolean? = null
)

data class TelegramProxyItem(
    val id: String = "",
    val name: String,
    val country: String,
    val countryFlag: String,
    val type: String,
    val link: String,
    val updateInfo: String = "Active",
    val isAvailable: Boolean = true,
    val isRecommended: Boolean = false
)

data class CustomConfigItem(
    val id: String = "",
    val name: String,
    val country: String,
    val countryFlag: String,
    val type: String,
    val link: String,
    val updateInfo: String = "Active",
    val isAvailable: Boolean = true,
    val isRecommended: Boolean = false
)

data class MardinConfigData(
    val appName: String = "Mardin",
    val lastUpdate: String = "",
    val telegramProxies: List<TelegramProxyItem> = emptyList(),
    val configs: List<CustomConfigItem> = emptyList(),
    val isUsingCachedData: Boolean = false,
    val proxyCountries: List<String> = emptyList(),
    val proxyProtocols: List<String> = emptyList(),
    val configCountries: List<String> = emptyList(),
    val configProtocols: List<String> = emptyList()
)

@JsonClass(generateAdapter = true)
data class StatsResponseDto(
    @Json(name = "install_count") val installCount: Long? = null
)

@JsonClass(generateAdapter = true)
data class UpdateResponseDto(
    @Json(name = "latest_version") val latestVersion: String? = null,
    @Json(name = "minimum_supported_version") val minimumSupportedVersion: String? = null,
    @Json(name = "update_required") val updateRequired: Boolean? = false,
    @Json(name = "download_url") val downloadUrl: String? = null,
    @Json(name = "release_notes") val releaseNotes: String? = null
)

data class UpdateInfo(
    val isUpdateAvailable: Boolean = false,
    val isUpdateRequired: Boolean = false,
    val latestVersion: String = "",
    val downloadUrl: String = "",
    val releaseNotes: String = ""
)

object CountryFlagUtils {
    fun getFlagEmoji(countryName: String?): String {
        if (countryName.isNullOrBlank()) return "🌐"
        val lower = countryName.trim().lowercase()
        return when {
            lower.contains("germany") || lower == "de" -> "🇩🇪"
            lower.contains("united states") || lower.contains("usa") || lower == "us" -> "🇺🇸"
            lower.contains("united kingdom") || lower.contains("uk") || lower.contains("great britain") || lower == "gb" -> "🇬🇧"
            lower.contains("netherlands") || lower.contains("holland") || lower == "nl" -> "🇳🇱"
            lower.contains("france") || lower == "fr" -> "🇫🇷"
            lower.contains("canada") || lower == "ca" -> "🇨🇦"
            lower.contains("singapore") || lower == "sg" -> "🇸🇬"
            lower.contains("japan") || lower == "jp" -> "🇯🇵"
            lower.contains("turkey") || lower.contains("türkiye") || lower == "tr" -> "🇹🇷"
            lower.contains("finland") || lower == "fi" -> "🇫🇮"
            lower.contains("sweden") || lower == "se" -> "🇸🇪"
            lower.contains("switzerland") || lower == "ch" -> "🇨🇭"
            lower.contains("poland") || lower == "pl" -> "🇵🇱"
            lower.contains("italy") || lower == "it" -> "🇮🇹"
            lower.contains("spain") || lower == "es" -> "🇪🇸"
            lower.contains("austria") || lower == "at" -> "🇦🇹"
            lower.contains("australia") || lower == "au" -> "🇦🇺"
            lower.contains("russia") || lower == "ru" -> "🇷🇺"
            lower.contains("iran") || lower == "ir" -> "🇮🇷"
            lower.contains("brazil") || lower == "br" -> "🇧🇷"
            lower.contains("india") || lower == "in" -> "🇮🇳"
            lower.contains("south korea") || lower.contains("korea") || lower == "kr" -> "🇰🇷"
            lower.contains("hong kong") || lower == "hk" -> "🇭🇰"
            lower.contains("uae") || lower.contains("emirates") || lower == "ae" -> "🇦🇪"
            else -> "🌐"
        }
    }
}
