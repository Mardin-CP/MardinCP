package com.example.data.repository

import android.content.Context
import com.example.BuildConfig
import com.example.data.local.ConfigDataStore
import com.example.data.model.CountryFlagUtils
import com.example.data.model.CustomConfigDto
import com.example.data.model.CustomConfigItem
import com.example.data.model.DataUpdateType
import com.example.data.model.MardinConfigData
import com.example.data.model.RemoteConfigResponse
import com.example.data.model.StatsResponseDto
import com.example.data.model.TelegramProxyDto
import com.example.data.model.TelegramProxyItem
import com.example.data.model.UpdateInfo
import com.example.data.model.UpdateResponseDto
import com.example.data.network.MardinRemoteConfig
import com.example.data.network.NetworkClient
import com.example.data.util.DateFormatUtils
import com.example.data.util.NetworkUtils
import com.squareup.moshi.JsonDataException
import com.squareup.moshi.JsonEncodingException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

sealed class FetchResult {
    data class Success(val data: MardinConfigData, val message: String = "Configuration updated successfully.") : FetchResult()
    data class Error(val message: String, val cachedData: MardinConfigData) : FetchResult()
}

data class DataUpdateCheckResult(
    val hasUpdate: Boolean,
    val updateType: DataUpdateType? = null,
    val remoteData: MardinConfigData? = null,
    val rawJson: String? = null,
    val remoteRevision: String = "",
    val proxyRevision: String = "",
    val configRevision: String = ""
)

class ConfigRepository(
    private val context: Context,
    private val dataStore: ConfigDataStore = ConfigDataStore(context)
) {
    private val jsonAdapter = NetworkClient.moshi.adapter(RemoteConfigResponse::class.java)
    private val statsAdapter = NetworkClient.moshi.adapter(StatsResponseDto::class.java)
    private val updateAdapter = NetworkClient.moshi.adapter(UpdateResponseDto::class.java)

    // Centralized remote configuration URL
    private val fixedRemoteConfigUrl: String = MardinRemoteConfig.URL_LIST.ifBlank { BuildConfig.FIXED_REMOTE_CONFIG_URL }

    @Volatile
    private var inMemoryConfig: MardinConfigData? = null

    val themeModeFlow: Flow<String> = dataStore.themeModeFlow
    val appLanguageFlow: Flow<String> = dataStore.appLanguageFlow
    val cachedInstallCountFlow: Flow<Long?> = dataStore.cachedInstallCountFlow

    suspend fun saveThemeMode(mode: String) {
        dataStore.saveThemeMode(mode)
    }

    suspend fun saveAppLanguage(languageCode: String) {
        dataStore.saveAppLanguage(languageCode)
    }

    /**
     * Fetches manual installation count from stats.json.
     * Caches value and returns null on failure or last cached value.
     */
    suspend fun fetchStats(): Long? = withContext(Dispatchers.IO) {
        try {
            val url = MardinRemoteConfig.URL_STATS.trim()
            val response = NetworkClient.apiService.fetchRawConfig(url)
            if (response.isSuccessful) {
                val raw = response.body()?.string()
                if (!raw.isNullOrBlank()) {
                    val parsed = statsAdapter.fromJson(raw)
                    if (parsed?.installCount != null) {
                        dataStore.saveCachedInstallCount(parsed.installCount)
                        return@withContext parsed.installCount
                    }
                }
            }
        } catch (_: Exception) {
            // Fail silently and return cached value
        }
        return@withContext dataStore.cachedInstallCountFlow.first()
    }

    /**
     * Checks update.json for new versions.
     */
    suspend fun checkForUpdates(currentVersion: String): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val url = MardinRemoteConfig.URL_UPDATE.trim()
            val response = NetworkClient.apiService.fetchRawConfig(url)
            if (response.isSuccessful) {
                val raw = response.body()?.string()
                if (!raw.isNullOrBlank()) {
                    val parsed = updateAdapter.fromJson(raw)
                    if (parsed != null && !parsed.latestVersion.isNullOrBlank()) {
                        val isNewer = isVersionNewer(parsed.latestVersion, currentVersion)
                        return@withContext UpdateInfo(
                            isUpdateAvailable = isNewer,
                            isUpdateRequired = parsed.updateRequired == true,
                            latestVersion = parsed.latestVersion,
                            downloadUrl = parsed.downloadUrl ?: "",
                            releaseNotes = parsed.releaseNotes ?: ""
                        )
                    }
                }
            }
        } catch (_: Exception) {
            // Network or parsing error, fail silently without disruption
        }
        return@withContext null
    }

    private fun isVersionNewer(latest: String?, current: String?): Boolean {
        if (latest.isNullOrBlank() || current.isNullOrBlank()) return false
        val cleanLatest = latest.trim().removePrefix("v").removePrefix("V")
        val cleanCurrent = current.trim().removePrefix("v").removePrefix("V")
        val latestParts = cleanLatest.split(".").mapNotNull { it.filter { char -> char.isDigit() }.toIntOrNull() }
        val currentParts = cleanCurrent.split(".").mapNotNull { it.filter { char -> char.isDigit() }.toIntOrNull() }
        val maxLen = maxOf(latestParts.size, currentParts.size)
        for (i in 0 until maxLen) {
            val l = latestParts.getOrElse(i) { 0 }
            val c = currentParts.getOrElse(i) { 0 }
            if (l > c) return true
            if (l < c) return false
        }
        return false
    }

    /**
     * Loads the currently stored cached configuration or default bundled fallback data.
     * Uses in-memory cache if available to prevent redundant disk I/O and JSON deserialization.
     */
    suspend fun loadCachedData(forceReload: Boolean = false): MardinConfigData = withContext(Dispatchers.IO) {
        if (!forceReload && inMemoryConfig != null) {
            return@withContext inMemoryConfig!!
        }

        val (cachedJson, lastUpdateTime) = dataStore.getCachedConfigSnapshot()

        if (!cachedJson.isNullOrBlank()) {
            try {
                val parsed = jsonAdapter.fromJson(cachedJson)
                if (parsed != null) {
                    val data = mapDtoToDomain(parsed, isCached = true)
                    if (data.telegramProxies.isNotEmpty() || data.configs.isNotEmpty()) {
                        val result = data.copy(
                            lastUpdate = if (data.lastUpdate.isNotBlank()) data.lastUpdate else (lastUpdateTime ?: ""),
                            isUsingCachedData = true
                        )
                        inMemoryConfig = result
                        return@withContext result
                    }
                }
            } catch (_: Exception) {
                // If corrupted, fallback to default seed
            }
        }

        // Return default bundled configurations if no cache exists
        val fallback = getDefaultFallbackData()
        inMemoryConfig = fallback
        fallback
    }

    /**
     * Fetches configuration from the permanent fixed remote URL.
     * Always retains previously saved working configurations on any failure.
     */
    suspend fun fetchRemoteConfig(): FetchResult = withContext(Dispatchers.IO) {
        val url = fixedRemoteConfigUrl.trim()

        if (!NetworkUtils.isNetworkAvailable(context)) {
            val currentCached = loadCachedData()
            return@withContext FetchResult.Error(
                message = "Using previous saved configuration data.",
                cachedData = currentCached.copy(isUsingCachedData = true)
            )
        }

        try {
            val response = NetworkClient.apiService.fetchRawConfig(url)
            if (!response.isSuccessful) {
                val currentCached = loadCachedData()
                return@withContext FetchResult.Error(
                    message = "Using previous saved configuration data.",
                    cachedData = currentCached.copy(isUsingCachedData = true)
                )
            }

            val rawBodyString = response.body()?.string()
            if (rawBodyString.isNullOrBlank()) {
                val currentCached = loadCachedData()
                return@withContext FetchResult.Error(
                    message = "Using previous saved configuration data.",
                    cachedData = currentCached.copy(isUsingCachedData = true)
                )
            }

            val parsedResponse = try {
                jsonAdapter.fromJson(rawBodyString)
            } catch (e: Exception) {
                val currentCached = loadCachedData()
                return@withContext FetchResult.Error(
                    message = "Using previous saved configuration data.",
                    cachedData = currentCached.copy(isUsingCachedData = true)
                )
            }

            if (parsedResponse == null) {
                val currentCached = loadCachedData()
                return@withContext FetchResult.Error(
                    message = "Using previous saved configuration data.",
                    cachedData = currentCached.copy(isUsingCachedData = true)
                )
            }

            val domainData = mapDtoToDomain(parsedResponse, isCached = false)

            if (domainData.telegramProxies.isEmpty() && domainData.configs.isEmpty()) {
                val currentCached = loadCachedData()
                return@withContext FetchResult.Error(
                    message = "Using previous saved configuration data.",
                    cachedData = currentCached.copy(isUsingCachedData = true)
                )
            }

            // Save new valid payload to persistent storage
            val updateTimestamp = if (domainData.lastUpdate.isNotBlank()) {
                domainData.lastUpdate
            } else {
                DateFormatUtils.formatCurrentTime()
            }
            dataStore.saveCachedConfig(rawBodyString, updateTimestamp)

            val remoteProxyRev = computeProxyFingerprint(parsedResponse.telegramProxies)
            val remoteConfigRev = computeConfigFingerprint(parsedResponse.configs)
            val remoteRevision = extractRemoteRevision(parsedResponse)
            dataStore.saveAppliedDataRevisions(remoteRevision, remoteProxyRev, remoteConfigRev)

            val successData = domainData.copy(lastUpdate = updateTimestamp, isUsingCachedData = false)
            inMemoryConfig = successData

            return@withContext FetchResult.Success(
                data = successData,
                message = "Configuration updated successfully."
            )

        } catch (e: Exception) {
            val currentCached = loadCachedData()
            return@withContext FetchResult.Error(
                message = "Using previous saved configuration data.",
                cachedData = currentCached.copy(isUsingCachedData = true)
            )
        }
    }

    /**
     * Checks if remote Config/Proxy data has changed compared to locally applied revision.
     * Accurately detects whether Configs only, Proxies only, or both have changed.
     */
    suspend fun checkForDataUpdates(): DataUpdateCheckResult = withContext(Dispatchers.IO) {
        val url = fixedRemoteConfigUrl.trim()
        if (!NetworkUtils.isNetworkAvailable(context)) {
            return@withContext DataUpdateCheckResult(hasUpdate = false)
        }

        try {
            val response = NetworkClient.apiService.fetchRawConfig(url)
            if (!response.isSuccessful) {
                return@withContext DataUpdateCheckResult(hasUpdate = false)
            }

            val rawBodyString = response.body()?.string()
            if (rawBodyString.isNullOrBlank()) {
                return@withContext DataUpdateCheckResult(hasUpdate = false)
            }

            val parsedResponse = try {
                jsonAdapter.fromJson(rawBodyString)
            } catch (_: Exception) {
                null
            } ?: return@withContext DataUpdateCheckResult(hasUpdate = false)

            val domainData = mapDtoToDomain(parsedResponse, isCached = false)
            if (domainData.telegramProxies.isEmpty() && domainData.configs.isEmpty()) {
                return@withContext DataUpdateCheckResult(hasUpdate = false)
            }

            val remoteProxyRev = computeProxyFingerprint(parsedResponse.telegramProxies)
            val remoteConfigRev = computeConfigFingerprint(parsedResponse.configs)
            val remoteRevision = extractRemoteRevision(parsedResponse)

            val (appliedRev, appliedProxyRev, appliedConfigRev) = dataStore.getAppliedDataRevisions()

            val baseProxyRev = appliedProxyRev ?: inMemoryConfig?.let {
                computeDomainProxyFingerprint(it.telegramProxies)
            }
            val baseConfigRev = appliedConfigRev ?: inMemoryConfig?.let {
                computeDomainConfigFingerprint(it.configs)
            }
            val baseRev = appliedRev ?: inMemoryConfig?.lastUpdate

            val proxiesChanged = baseProxyRev != null && baseProxyRev != remoteProxyRev
            val configsChanged = baseConfigRev != null && baseConfigRev != remoteConfigRev
            val revisionChanged = baseRev != null && baseRev != remoteRevision

            val updateType: DataUpdateType? = when {
                proxiesChanged && configsChanged -> DataUpdateType.BOTH
                configsChanged -> DataUpdateType.CONFIGS_ONLY
                proxiesChanged -> DataUpdateType.PROXIES_ONLY
                revisionChanged -> DataUpdateType.BOTH
                else -> null
            }

            if (updateType != null) {
                return@withContext DataUpdateCheckResult(
                    hasUpdate = true,
                    updateType = updateType,
                    remoteData = domainData,
                    rawJson = rawBodyString,
                    remoteRevision = remoteRevision,
                    proxyRevision = remoteProxyRev,
                    configRevision = remoteConfigRev
                )
            }

            return@withContext DataUpdateCheckResult(hasUpdate = false)
        } catch (_: Exception) {
            return@withContext DataUpdateCheckResult(hasUpdate = false)
        }
    }

    /**
     * Applies remote data update, saving it to cache and updating applied revisions.
     */
    suspend fun applyDataUpdate(
        domainData: MardinConfigData,
        rawJson: String,
        remoteRevision: String,
        proxyRevision: String,
        configRevision: String
    ): MardinConfigData = withContext(Dispatchers.IO) {
        val updateTimestamp = if (domainData.lastUpdate.isNotBlank()) domainData.lastUpdate else DateFormatUtils.formatCurrentTime()
        dataStore.saveCachedConfig(rawJson, updateTimestamp)
        dataStore.saveAppliedDataRevisions(remoteRevision, proxyRevision, configRevision)
        val successData = domainData.copy(lastUpdate = updateTimestamp, isUsingCachedData = false)
        inMemoryConfig = successData
        successData
    }

    fun computeProxyFingerprint(proxies: List<TelegramProxyDto>?): String {
        if (proxies.isNullOrEmpty()) return "empty"
        return proxies.joinToString(";") { "${it.name}|${it.link}|${it.type}|${it.recommended}" }.hashCode().toString()
    }

    fun computeConfigFingerprint(configs: List<CustomConfigDto>?): String {
        if (configs.isNullOrEmpty()) return "empty"
        return configs.joinToString(";") { "${it.name}|${it.link}|${it.config}|${it.type}|${it.recommended}" }.hashCode().toString()
    }

    private fun computeDomainProxyFingerprint(proxies: List<TelegramProxyItem>): String {
        if (proxies.isEmpty()) return "empty"
        return proxies.joinToString(";") { "${it.name}|${it.link}|${it.type}|${it.isRecommended}" }.hashCode().toString()
    }

    private fun computeDomainConfigFingerprint(configs: List<CustomConfigItem>): String {
        if (configs.isEmpty()) return "empty"
        return configs.joinToString(";") { "${it.name}|${it.link}|${it.type}|${it.isRecommended}" }.hashCode().toString()
    }

    fun extractRemoteRevision(dto: RemoteConfigResponse): String {
        val field = dto.lastUpdate?.trim()?.ifBlank { null }
            ?: dto.version?.trim()?.ifBlank { null }
            ?: dto.revision?.trim()?.ifBlank { null }
            ?: dto.updatedAt?.trim()?.ifBlank { null }
        return field ?: "hash_${computeProxyFingerprint(dto.telegramProxies)}_${computeConfigFingerprint(dto.configs)}"
    }

    /**
     * Tolerant item-by-item mapper. If one item is invalid, it ignores the broken item and loads valid items.
     * Uses stable deterministic IDs based on item attributes for optimal LazyColumn diffing.
     */
    private fun mapDtoToDomain(dto: RemoteConfigResponse, isCached: Boolean): MardinConfigData {
        val rawProxies = mutableListOf<Pair<TelegramProxyItem, Boolean>>()
        dto.telegramProxies?.forEach { proxyDto ->
            val link = proxyDto.link?.trim() ?: ""
            if (link.isNotBlank()) {
                val name = proxyDto.name?.trim()?.ifBlank { "Telegram Proxy" } ?: "Telegram Proxy"
                val country = proxyDto.country?.trim()?.ifBlank { "Unknown" } ?: "Unknown"
                val type = proxyDto.type?.trim()?.ifBlank { "MTProto" } ?: "MTProto"
                val updateInfo = proxyDto.updateInfo?.trim()?.ifBlank { "Active" } ?: "Active"
                val stableId = "${type}_${country}_${link.hashCode()}"
                val isExplicitRec = proxyDto.recommended == true

                rawProxies.add(
                    TelegramProxyItem(
                        id = stableId,
                        name = name,
                        country = country,
                        countryFlag = CountryFlagUtils.getFlagEmoji(country),
                        type = type,
                        link = link,
                        updateInfo = updateInfo,
                        isAvailable = true,
                        isRecommended = false
                    ) to isExplicitRec
                )
            }
        }

        val validProxies = applyRecommendationLogic(
            items = rawProxies.map { it.first },
            explicitFlags = rawProxies.map { it.second }
        ) { item, isRec -> item.copy(isRecommended = isRec) }

        val rawConfigs = mutableListOf<Pair<CustomConfigItem, Boolean>>()
        dto.configs?.forEach { configDto ->
            val link = configDto.link?.trim()?.ifBlank { null } ?: configDto.config?.trim() ?: ""
            if (link.isNotBlank()) {
                val name = configDto.name?.trim()?.ifBlank { "Custom Config" } ?: "Custom Config"
                val country = configDto.country?.trim()?.ifBlank { "Unknown" } ?: "Unknown"
                val rawType = configDto.type?.trim() ?: detectProtocolType(link)
                val type = rawType.ifBlank { "VLESS" }
                val updateInfo = configDto.updateInfo?.trim()?.ifBlank {
                    if (dto.lastUpdate.isNullOrBlank()) "Active" else "Updated ${dto.lastUpdate}"
                } ?: "Active"
                val stableId = "${type}_${country}_${link.hashCode()}"
                val isExplicitRec = configDto.recommended == true

                rawConfigs.add(
                    CustomConfigItem(
                        id = stableId,
                        name = name,
                        country = country,
                        countryFlag = CountryFlagUtils.getFlagEmoji(country),
                        type = type,
                        link = link,
                        updateInfo = updateInfo,
                        isAvailable = true,
                        isRecommended = false
                    ) to isExplicitRec
                )
            }
        }

        val validConfigs = applyRecommendationLogic(
            items = rawConfigs.map { it.first },
            explicitFlags = rawConfigs.map { it.second }
        ) { item, isRec -> item.copy(isRecommended = isRec) }

        val pCountries = validProxies.map { it.country }.distinct().sorted()
        val pProtocols = validProxies.map { it.type }.distinct().sorted()
        val cCountries = validConfigs.map { it.country }.distinct().sorted()
        val cProtocols = validConfigs.map { it.type }.distinct().sorted()

        return MardinConfigData(
            appName = dto.appName?.trim()?.ifBlank { "Mardin" } ?: "Mardin",
            lastUpdate = dto.lastUpdate?.trim() ?: "",
            telegramProxies = validProxies,
            configs = validConfigs,
            isUsingCachedData = isCached,
            proxyCountries = pCountries,
            proxyProtocols = pProtocols,
            configCountries = cCountries,
            configProtocols = cProtocols
        )
    }

    private fun detectProtocolType(link: String): String {
        val lower = link.lowercase()
        return when {
            lower.startsWith("vless://") -> "VLESS"
            lower.startsWith("vmess://") -> "VMess"
            lower.startsWith("trojan://") -> "Trojan"
            lower.startsWith("ss://") -> "Shadowsocks"
            lower.startsWith("ssr://") -> "ShadowsocksR"
            lower.startsWith("hy2://") || lower.startsWith("hysteria2://") -> "Hysteria2"
            lower.startsWith("tuic://") -> "TUIC"
            lower.startsWith("wireguard://") || lower.startsWith("wg://") -> "WireGuard"
            lower.startsWith("tg://") -> "MTProto"
            else -> "Custom"
        }
    }

    private fun getDefaultFallbackData(): MardinConfigData {
        val proxies = listOf(
            TelegramProxyItem(
                id = "fallback_proxy_de",
                name = "Germany Fast MTProto",
                country = "Germany",
                countryFlag = "🇩🇪",
                type = "MTProto",
                link = "tg://proxy?server=de.proxy.mardin.net&port=443&secret=ee112233445566778899aabbccddeeff117777772e676f6f676c652e636f6d",
                updateInfo = "Active",
                isAvailable = true,
                isRecommended = true
            ),
            TelegramProxyItem(
                id = "fallback_proxy_nl",
                name = "Netherlands MTProto",
                country = "Netherlands",
                countryFlag = "🇳🇱",
                type = "MTProto",
                link = "tg://proxy?server=nl.proxy.mardin.net&port=8443&secret=dd00112233445566778899aabbccddeeff11",
                updateInfo = "Active",
                isAvailable = true,
                isRecommended = false
            ),
            TelegramProxyItem(
                id = "fallback_proxy_fi",
                name = "Finland MTProto",
                country = "Finland",
                countryFlag = "🇫🇮",
                type = "MTProto",
                link = "tg://proxy?server=fi.proxy.mardin.net&port=443&secret=7gAAAAAAAAAAAAAAAAAAAAB3d3cuZ29vZ2xlLmNvbQ",
                updateInfo = "Active",
                isAvailable = true,
                isRecommended = false
            )
        )

        val configs = listOf(
            CustomConfigItem(
                id = "fallback_config_de_vless",
                name = "Germany VLESS Reality",
                country = "Germany",
                countryFlag = "🇩🇪",
                type = "VLESS",
                link = "vless://4a781b4b-9e96-419b-a017-91f855d045d6@de.cloud.mardin.net:443?type=tcp&security=reality&pbk=Z19zPz7N0Y9T0N4-q8Qy2e9L2E4K_P0K1N4-q8Qy2e8&fp=chrome&sni=www.microsoft.com&sid=7b1a&spx=%2F#Germany-VLESS",
                updateInfo = "Active",
                isAvailable = true,
                isRecommended = true
            ),
            CustomConfigItem(
                id = "fallback_config_nl_vmess",
                name = "Netherlands VMess WS",
                country = "Netherlands",
                countryFlag = "🇳🇱",
                type = "VMess",
                link = "vmess://eyJhZGQiOiJubC5jbG91ZC5tYXJkaW4ubmV0IiwiYWlkIjoiMCIsImhvc3QiOiJubC5jbG91ZC5tYXJkaW4ubmV0IiwiaWQiOiI3YTg5YmNkZS0xMjM0LTU2NzgtOTAxMi0zNDU2Nzg5MGFiY2QiLCJuZXQiOiJ3cyIsInBhdGgiOiIvd3MiLCJwb3J0IjoiNDQzIiwicHMiOiJOZXRoZXJsYW5kcy1WTWVzcyIsInNjeSI6ImF1dG8iLCJzbmkiOiJubC5jbG91ZC5tYXJkaW4ubmV0IiwidGxzIjoidGxzIiwidHlwZSI6Im5vbmUidiI6IjIifQ==",
                updateInfo = "Active",
                isAvailable = true
            ),
            CustomConfigItem(
                id = "fallback_config_us_trojan",
                name = "United States Trojan TLS",
                country = "United States",
                countryFlag = "🇺🇸",
                type = "Trojan",
                link = "trojan://mardin-secret-pass-2026@us.cloud.mardin.net:443?security=tls&headerType=none&type=tcp&sni=us.cloud.mardin.net#USA-Trojan",
                updateInfo = "Active",
                isAvailable = true
            ),
            CustomConfigItem(
                id = "fallback_config_sg_ss",
                name = "Singapore Shadowsocks 2022",
                country = "Singapore",
                countryFlag = "🇸🇬",
                type = "Shadowsocks",
                link = "ss://2022-blake3-aes-128-gcm:dGVzdGtleTEyMzQ1Njc4OQ==@sg.cloud.mardin.net:8388#Singapore-SS",
                updateInfo = "Active",
                isAvailable = true
            ),
            CustomConfigItem(
                id = "fallback_config_fr_vless",
                name = "France VLESS gRPC",
                country = "France",
                countryFlag = "🇫🇷",
                type = "VLESS",
                link = "vless://b7498c12-3456-789a-bcde-f0123456789a@fr.cloud.mardin.net:443?type=grpc&security=tls&serviceName=grpc-mardin&sni=fr.cloud.mardin.net#France-VLESS-gRPC",
                updateInfo = "Active",
                isAvailable = true
            )
        )

        return MardinConfigData(
            appName = "Mardin",
            lastUpdate = DateFormatUtils.formatCurrentTime(),
            telegramProxies = proxies,
            configs = configs,
            isUsingCachedData = true,
            proxyCountries = listOf("Finland", "Germany", "Netherlands"),
            proxyProtocols = listOf("MTProto"),
            configCountries = listOf("France", "Germany", "Netherlands", "Singapore", "United States"),
            configProtocols = listOf("Shadowsocks", "Trojan", "VLESS", "VMess")
        )
    }

    companion object {
        /**
         * Reusable recommendation processor for proxies and configurations.
         * Priority 1: If one or more items explicitly have recommended: true, those items are recommended.
         * Priority 2: If NO item has recommended: true, automatically treat the FIRST item (index 0) as recommended.
         * If the list is empty, return empty list (no recommendation).
         * List order is strictly preserved.
         */
        fun <T, R> applyRecommendationLogic(
            items: List<T>,
            explicitFlags: List<Boolean>,
            markRecommended: (T, Boolean) -> R
        ): List<R> {
            if (items.isEmpty()) return emptyList()
            val hasAnyExplicit = explicitFlags.any { it }
            return items.mapIndexed { index, item ->
                val isRec = if (hasAnyExplicit) {
                    explicitFlags.getOrElse(index) { false }
                } else {
                    index == 0
                }
                markRecommended(item, isRec)
            }
        }
    }
}
