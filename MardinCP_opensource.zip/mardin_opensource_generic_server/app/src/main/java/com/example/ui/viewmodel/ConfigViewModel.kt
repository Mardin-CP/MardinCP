package com.example.ui.viewmodel

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.SystemClock
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.R
import com.example.data.model.CustomConfigItem
import com.example.data.model.DataUpdateType
import com.example.data.model.MardinConfigData
import com.example.data.model.TelegramProxyItem
import com.example.data.model.UpdateInfo
import com.example.data.repository.ConfigRepository
import com.example.data.repository.FetchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.NumberFormat
import java.util.Locale

enum class FeedbackType {
    NONE,
    LOADING,
    SUCCESS,
    ERROR
}

data class ConfigUiState(
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val configData: MardinConfigData = MardinConfigData(),
    val selectedTab: Int = 0, // 0 = Telegram Proxies, 1 = Configurations, 2 = Settings
    val searchQuery: String = "",
    val selectedCountry: String? = null,
    val selectedProtocol: String? = null,
    val feedbackMessage: String? = null,
    val feedbackType: FeedbackType = FeedbackType.NONE,
    val snackbarMessage: String? = null,
    val themeMode: String = "SYSTEM",
    val appLanguage: String = "en",
    val installCount: Long? = null,
    val isCheckingUpdates: Boolean = false,
    val updateInfo: UpdateInfo? = null,
    val showUpdateDialog: Boolean = false,
    // Requirement 1: Mardin App Update Notification
    val isAppUpdateAvailable: Boolean = false,
    val appUpdateInfo: UpdateInfo? = null,
    val isAppUpdateDismissed: Boolean = false,
    // Requirement 2: Config / Proxy Data Update Notification
    val dataUpdateType: DataUpdateType? = null,
    val isDataUpdateDismissed: Boolean = false,
    val pendingDataUpdate: MardinConfigData? = null,
    val pendingDataRawJson: String? = null,
    val pendingDataRemoteRev: String = "",
    val pendingDataProxyRev: String = "",
    val pendingDataConfigRev: String = ""
) {
    val formattedInstallCount: String
        get() {
            if (installCount == null) return "—"
            return try {
                val locale = if (appLanguage == "fa") Locale("fa", "IR") else Locale.ENGLISH
                NumberFormat.getNumberInstance(locale).format(installCount)
            } catch (_: Exception) {
                installCount.toString()
            }
        }

    val filteredProxies: List<TelegramProxyItem>
        get() {
            if (searchQuery.isBlank() && selectedCountry == null && selectedProtocol == null) {
                return configData.telegramProxies
            }
            val query = searchQuery.trim()
            return configData.telegramProxies.filter { proxy ->
                val matchesSearch = query.isEmpty() ||
                        proxy.name.contains(query, ignoreCase = true) ||
                        proxy.country.contains(query, ignoreCase = true) ||
                        proxy.type.contains(query, ignoreCase = true)
                val matchesCountry = selectedCountry == null || proxy.country.equals(selectedCountry, ignoreCase = true)
                val matchesProtocol = selectedProtocol == null || proxy.type.equals(selectedProtocol, ignoreCase = true)
                matchesSearch && matchesCountry && matchesProtocol
            }
        }

    val filteredConfigs: List<CustomConfigItem>
        get() {
            if (searchQuery.isBlank() && selectedCountry == null && selectedProtocol == null) {
                return configData.configs
            }
            val query = searchQuery.trim()
            return configData.configs.filter { config ->
                val matchesSearch = query.isEmpty() ||
                        config.name.contains(query, ignoreCase = true) ||
                        config.country.contains(query, ignoreCase = true) ||
                        config.type.contains(query, ignoreCase = true)
                val matchesCountry = selectedCountry == null || config.country.equals(selectedCountry, ignoreCase = true)
                val matchesProtocol = selectedProtocol == null || config.type.equals(selectedProtocol, ignoreCase = true)
                matchesSearch && matchesCountry && matchesProtocol
            }
        }

    val availableCountries: List<String>
        get() = if (selectedTab == 0) configData.proxyCountries else configData.configCountries

    val availableProtocols: List<String>
        get() = if (selectedTab == 0) configData.proxyProtocols else configData.configProtocols
}

class ConfigViewModel(
    private val repository: ConfigRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConfigUiState())
    val uiState: StateFlow<ConfigUiState> = _uiState.asStateFlow()

    private var refreshJob: Job? = null
    private var statsJob: Job? = null
    private var checkUpdatesJob: Job? = null
    private var lastTelegramLaunchTime = -10000L
    private var lastShareTime = -10000L
    private var lastShareApkTime = -10000L
    private var lastOpenWithTime = -10000L
    private var lastCopyTime = -10000L

    init {
        // Observe theme mode
        viewModelScope.launch {
            repository.themeModeFlow.collectLatest { mode ->
                _uiState.update { it.copy(themeMode = mode) }
            }
        }

        // Observe language preference
        viewModelScope.launch {
            repository.appLanguageFlow.collectLatest { lang ->
                _uiState.update { it.copy(appLanguage = lang) }
            }
        }

        // Observe cached install count
        viewModelScope.launch {
            repository.cachedInstallCountFlow.collectLatest { count ->
                if (count != null) {
                    _uiState.update { it.copy(installCount = count) }
                }
            }
        }

        // On launch: Load cached data immediately, check for APK updates and remote data updates in background
        viewModelScope.launch {
            val cached = repository.loadCachedData()
            _uiState.update { it.copy(configData = cached) }
            refreshStats()
            checkForUpdatesSilently()
            checkRemoteDataUpdateSilently()
        }
    }

    fun onTabSelected(tab: Int) {
        _uiState.update {
            it.copy(
                selectedTab = tab,
                selectedCountry = null,
                selectedProtocol = null
            )
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun onCountrySelected(country: String?) {
        _uiState.update {
            it.copy(selectedCountry = if (it.selectedCountry == country) null else country)
        }
    }

    fun onProtocolSelected(protocol: String?) {
        _uiState.update {
            it.copy(selectedProtocol = if (it.selectedProtocol == protocol) null else protocol)
        }
    }

    /**
     * Refreshes configurations from the permanent fixed remote JSON URL.
     */
    fun refreshConfigs(showFullScreenLoading: Boolean = false, isPullRefresh: Boolean = false) {
        if (refreshJob?.isActive == true) return
        refreshJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = showFullScreenLoading,
                    isRefreshing = isPullRefresh,
                    feedbackMessage = "Updating...",
                    feedbackType = FeedbackType.LOADING
                )
            }

            // Also refresh stats simultaneously
            launch { refreshStats() }

            when (val result = repository.fetchRemoteConfig()) {
                is FetchResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isRefreshing = false,
                            configData = result.data,
                            feedbackMessage = result.message,
                            feedbackType = FeedbackType.SUCCESS,
                            snackbarMessage = result.message
                        )
                    }
                }
                is FetchResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isRefreshing = false,
                            configData = result.cachedData,
                            feedbackMessage = result.message,
                            feedbackType = FeedbackType.ERROR,
                            snackbarMessage = result.message
                        )
                    }
                }
            }
        }
    }

    /**
     * Fetches manual installation count from stats.json
     */
    fun refreshStats() {
        if (statsJob?.isActive == true) return
        statsJob = viewModelScope.launch {
            val count = repository.fetchStats()
            if (count != null) {
                _uiState.update { it.copy(installCount = count) }
            }
        }
    }

    /**
     * Checks for updates silently in the background on app start.
     * Shows compact top banner without popping up an intrusive blocking dialog.
     */
    private fun checkForUpdatesSilently() {
        viewModelScope.launch {
            val currentVersion = BuildConfig.VERSION_NAME
            val update = repository.checkForUpdates(currentVersion)
            if (update != null && update.isUpdateAvailable) {
                _uiState.update {
                    it.copy(
                        updateInfo = update,
                        appUpdateInfo = update,
                        isAppUpdateAvailable = true,
                        isAppUpdateDismissed = false,
                        showUpdateDialog = false // Top banner shown instead of blocking modal
                    )
                }
            }
        }
    }

    /**
     * Checks if remote data (configs/proxies) has changed on the remote server.
     * Accurately displays the top data update notification if changes exist.
     */
    fun checkRemoteDataUpdateSilently() {
        viewModelScope.launch {
            val result = repository.checkForDataUpdates()
            if (result.hasUpdate && result.updateType != null) {
                _uiState.update {
                    it.copy(
                        dataUpdateType = result.updateType,
                        isDataUpdateDismissed = false,
                        pendingDataUpdate = result.remoteData,
                        pendingDataRawJson = result.rawJson,
                        pendingDataRemoteRev = result.remoteRevision,
                        pendingDataProxyRev = result.proxyRevision,
                        pendingDataConfigRev = result.configRevision
                    )
                }
            }
        }
    }

    /**
     * User clicks "Update data" on the top notification.
     * Applies remote config/proxy data, stores latest revision, and hides notification.
     */
    fun applyRemoteDataUpdate() {
        val state = _uiState.value
        val pending = state.pendingDataUpdate
        val rawJson = state.pendingDataRawJson
        if (pending != null && rawJson != null) {
            viewModelScope.launch {
                val applied = repository.applyDataUpdate(
                    domainData = pending,
                    rawJson = rawJson,
                    remoteRevision = state.pendingDataRemoteRev,
                    proxyRevision = state.pendingDataProxyRev,
                    configRevision = state.pendingDataConfigRev
                )
                _uiState.update {
                    it.copy(
                        configData = applied,
                        dataUpdateType = null,
                        isDataUpdateDismissed = false,
                        pendingDataUpdate = null,
                        pendingDataRawJson = null,
                        feedbackMessage = "Configuration updated successfully.",
                        feedbackType = FeedbackType.SUCCESS,
                        snackbarMessage = "Configuration updated successfully."
                    )
                }
            }
        } else {
            refreshConfigs(showFullScreenLoading = false)
            _uiState.update {
                it.copy(
                    dataUpdateType = null,
                    isDataUpdateDismissed = false
                )
            }
        }
    }

    fun dismissAppUpdateNotification() {
        _uiState.update { it.copy(isAppUpdateDismissed = true) }
    }

    fun dismissDataUpdateNotification() {
        _uiState.update { it.copy(isDataUpdateDismissed = true) }
    }

    /**
     * Manual update check triggered from Settings screen.
     */
    fun checkUpdatesManual(context: Context) {
        if (checkUpdatesJob?.isActive == true) return
        checkUpdatesJob = viewModelScope.launch {
            _uiState.update { it.copy(isCheckingUpdates = true) }
            val currentVersion = BuildConfig.VERSION_NAME
            val update = repository.checkForUpdates(currentVersion)
            _uiState.update { it.copy(isCheckingUpdates = false) }

            if (update != null && update.isUpdateAvailable) {
                _uiState.update {
                    it.copy(
                        updateInfo = update,
                        appUpdateInfo = update,
                        isAppUpdateAvailable = true,
                        isAppUpdateDismissed = false,
                        showUpdateDialog = true
                    )
                }
            } else {
                _uiState.update {
                    it.copy(snackbarMessage = context.getString(R.string.app_up_to_date))
                }
            }
        }
    }

    fun dismissUpdateDialog() {
        _uiState.update { it.copy(showUpdateDialog = false) }
    }

    fun openUpdateDownload(context: Context, url: String) {
        dismissUpdateDialog()
        dismissAppUpdateNotification()
        if (url.isNotBlank()) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                _uiState.update { it.copy(snackbarMessage = "Unable to open download link.") }
            }
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            repository.saveThemeMode(mode)
            _uiState.update { it.copy(themeMode = mode) }
        }
    }

    fun setAppLanguage(languageCode: String) {
        viewModelScope.launch {
            repository.saveAppLanguage(languageCode)
            _uiState.update { it.copy(appLanguage = languageCode) }
        }
    }

    /**
     * Copies configuration or proxy link to clipboard and shows localized "Copied successfully."
     */
    fun copyToClipboard(context: Context, label: String, text: String) {
        val now = SystemClock.uptimeMillis()
        if (now - lastCopyTime < 500L) return
        lastCopyTime = now

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (clipboard != null) {
            val clip = ClipData.newPlainText(label, text)
            clipboard.setPrimaryClip(clip)
            _uiState.update { it.copy(snackbarMessage = context.getString(R.string.copied_successfully)) }
        } else {
            _uiState.update { it.copy(snackbarMessage = context.getString(R.string.clipboard_unavailable)) }
        }
    }

    companion object {
        private val TELEGRAM_PACKAGES = listOf(
            "org.telegram.messenger",
            "org.telegram.messenger.web",
            "org.thunderdog.challegram",
            "org.telegram.plus",
            "org.telegram.messenger.beta",
            "org.telegram.BETA",
            "com.nekogram.nekox",
            "app.zenith.messenger",
            "org.vidogram.messenger"
        )

        private const val V2RAY_PACKAGE = "com.v2ray.ang"
    }

    /**
     * Converts proxy links into native tg://proxy? or tg://socks? deep links.
     * Prevents Chrome/browsers from opening when tapping a Telegram proxy.
     */
    fun buildTelegramDeepLink(rawLink: String): Uri {
        val trimmed = rawLink.trim()
        if (trimmed.startsWith("tg://", ignoreCase = true)) {
            return Uri.parse(trimmed)
        }

        val parsed = try {
            Uri.parse(trimmed)
        } catch (_: Exception) {
            null
        }

        if (parsed != null) {
            val host = parsed.host?.lowercase().orEmpty()
            val path = parsed.path?.lowercase().orEmpty()
            val query = parsed.encodedQuery

            if ((host == "t.me" || host == "telegram.me" || host.endsWith(".t.me")) && !query.isNullOrBlank()) {
                val endpoint = if (path.contains("socks")) "socks" else "proxy"
                return Uri.parse("tg://$endpoint?$query")
            }
        }

        val queryIndex = trimmed.indexOf('?')
        if (queryIndex != -1) {
            val beforeQuery = trimmed.substring(0, queryIndex).lowercase()
            val query = trimmed.substring(queryIndex + 1)
            val endpoint = if (beforeQuery.contains("socks")) "socks" else "proxy"
            return Uri.parse("tg://$endpoint?$query")
        }

        if (trimmed.contains("server=")) {
            return Uri.parse("tg://proxy?$trimmed")
        }

        return Uri.parse(trimmed)
    }

    /**
     * Builds HTTPS Telegram deep-link URI (e.g. https://t.me/proxy?...).
     * Used ONLY targeted to a verified Telegram package.
     */
    private fun buildTelegramHttpsUri(rawLink: String): Uri {
        val trimmed = rawLink.trim()
        if (trimmed.startsWith("https://t.me/", ignoreCase = true)) {
            return Uri.parse(trimmed)
        }
        val queryIndex = trimmed.indexOf('?')
        if (queryIndex != -1) {
            val beforeQuery = trimmed.substring(0, queryIndex).lowercase()
            val query = trimmed.substring(queryIndex + 1)
            val endpoint = if (beforeQuery.contains("socks")) "socks" else "proxy"
            return Uri.parse("https://t.me/$endpoint?$query")
        }
        return Uri.parse("https://t.me/proxy?$trimmed")
    }

    /**
     * Opens Telegram proxy intent directly in Telegram.
     * Routes directly to Telegram via native deep links (tg://proxy or tg://socks)
     * and targets installed Telegram apps without ever routing to Chrome or a web browser.
     * If Telegram is not installed, shows a friendly message without crashing.
     */
    fun openTelegramProxy(context: Context, link: String) {
        val now = SystemClock.uptimeMillis()
        if (now - lastTelegramLaunchTime < 600L) return
        lastTelegramLaunchTime = now

        val packageManager = context.packageManager
        val tgDeepLinkUri = buildTelegramDeepLink(link)

        // Primary tg:// intent
        val tgIntent = Intent(Intent.ACTION_VIEW, tgDeepLinkUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        // Query activities capable of handling tg://
        val tgResolvers = try {
            packageManager.queryIntentActivities(tgIntent, PackageManager.MATCH_DEFAULT_ONLY)
        } catch (_: Exception) {
            emptyList()
        }

        // Detect installed Telegram applications
        val installedTelegramPkgs = TELEGRAM_PACKAGES.filter { pkg ->
            try {
                packageManager.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
        }

        var launched = false

        // Strategy 1: If standard Telegram apps resolved the tg:// deep link
        if (tgResolvers.isNotEmpty()) {
            if (tgResolvers.size == 1) {
                // Single Telegram app installed: launch directly
                tgIntent.setPackage(tgResolvers[0].activityInfo.packageName)
                try {
                    context.startActivity(tgIntent)
                    launched = true
                } catch (_: Exception) {
                    launched = false
                }
            } else {
                // Multiple Telegram apps installed: show Telegram chooser
                val chooser = Intent.createChooser(tgIntent, context.getString(R.string.open_telegram)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(chooser)
                    launched = true
                } catch (_: Exception) {
                    launched = false
                }
            }
        }

        // Strategy 2: If queryIntentActivities didn't match directly, target installed Telegram package
        if (!launched && installedTelegramPkgs.isNotEmpty()) {
            val targetPkg = installedTelegramPkgs.first()
            tgIntent.setPackage(targetPkg)
            try {
                context.startActivity(tgIntent)
                launched = true
            } catch (_: Exception) {
                // Try HTTPS deep link targeted EXCLUSIVELY to this Telegram package (NEVER browser)
                try {
                    val httpsIntent = Intent(Intent.ACTION_VIEW, buildTelegramHttpsUri(link)).apply {
                        setPackage(targetPkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(httpsIntent)
                    launched = true
                } catch (_: Exception) {
                    // Try launching the Telegram app with data attached
                    try {
                        val launchIntent = packageManager.getLaunchIntentForPackage(targetPkg)?.apply {
                            data = tgDeepLinkUri
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        if (launchIntent != null) {
                            context.startActivity(launchIntent)
                            launched = true
                        }
                    } catch (_: Exception) {
                    }
                }
            }
        }

        // If Telegram is not installed, inform user gracefully without launching Chrome or crashing
        if (!launched) {
            _uiState.update {
                it.copy(snackbarMessage = context.getString(R.string.telegram_not_installed))
            }
        }
    }

    /**
     * Uses Android native share sheet so user can share configuration link.
     */
    fun shareConfig(context: Context, title: String, text: String) {
        val now = SystemClock.uptimeMillis()
        if (now - lastShareTime < 600L) return
        lastShareTime = now

        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_TEXT, text)
                putExtra(Intent.EXTRA_TITLE, title)
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, context.getString(R.string.share_config))
            shareIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            _uiState.update { it.copy(snackbarMessage = context.getString(R.string.unable_open_share)) }
        }
    }

    /**
     * Shares the currently installed Mardin APK file via the standard Android Sharesheet.
     * Locates the installed APK from ApplicationInfo, creates a secure content URI using FileProvider,
     * sets the MIME type to application/vnd.android.package-archive, and displays the system chooser.
     */
    fun shareApk(context: Context) {
        val now = SystemClock.uptimeMillis()
        if (now - lastShareApkTime < 600L) return
        lastShareApkTime = now

        try {
            val sourceDir = context.applicationInfo.sourceDir
            val originalApk = sourceDir?.let { File(it) }
            if (originalApk == null || !originalApk.exists() || !originalApk.canRead()) {
                throw IllegalStateException("Installed APK file not accessible")
            }

            val versionName = try {
                val pkgInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                pkgInfo.versionName?.takeIf { it.isNotBlank() } ?: BuildConfig.VERSION_NAME
            } catch (_: Exception) {
                BuildConfig.VERSION_NAME
            }

            val cleanVersion = versionName.ifBlank { "2.2.0" }
            val apkDir = File(context.cacheDir, "shared_apks").apply { mkdirs() }
            val destApk = File(apkDir, "Mardin-$cleanVersion.apk")

            // Copy installed APK to cache if not already copied or if size changed
            if (!destApk.exists() || destApk.length() != originalApk.length()) {
                originalApk.copyTo(destApk, overwrite = true)
            }

            val authority = "${BuildConfig.APPLICATION_ID}.fileprovider"
            val apkUri = FileProvider.getUriForFile(context, authority, destApk)

            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, apkUri)
                clipData = ClipData.newUri(context.contentResolver, "Mardin APK", apkUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(
                sendIntent,
                context.getString(R.string.share_mardin)
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(chooser)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(snackbarMessage = context.getString(R.string.unable_share_apk))
            }
        }
    }

    /**
     * Config "Open with" -> V2Ray.
     * Restores the original V2Ray Open With behavior:
     * Mardin -> Open With -> V2Ray -> open/import the configuration.
     * Passes the actual configuration URI to V2Ray exactly as the original implementation did.
     */
    fun openConfigWith(context: Context, link: String) {
        openWithClient(context, link)
    }

    /**
     * Opens V2Ray using Android's Intent system to import the configuration link.
     * Copies the configuration link to clipboard, parses the protocol URI,
     * and directly opens V2Ray with the URI.
     */
    fun openWithClient(context: Context, link: String) {
        val now = SystemClock.uptimeMillis()
        if (now - lastOpenWithTime < 600L) return
        lastOpenWithTime = now

        val trimmedLink = link.trim()
        if (trimmedLink.isBlank()) {
            _uiState.update { it.copy(snackbarMessage = context.getString(R.string.invalid_config_link)) }
            return
        }

        // Copy configuration to clipboard for seamless import or fallback
        copyToClipboard(context, "Config", trimmedLink)

        val uri = try {
            Uri.parse(trimmedLink)
        } catch (_: Exception) {
            null
        }

        if (uri == null || uri.scheme.isNullOrBlank()) {
            _uiState.update { it.copy(snackbarMessage = context.getString(R.string.invalid_config_link)) }
            return
        }

        val packageManager = context.packageManager
        var started = false

        // Check if V2Ray is installed
        val isV2RayInstalled = try {
            packageManager.getPackageInfo(V2RAY_PACKAGE, 0)
            true
        } catch (_: Exception) {
            false
        }

        if (isV2RayInstalled) {
            // Attempt 1: Direct ACTION_VIEW targeting V2Ray package
            try {
                val directIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(V2RAY_PACKAGE)
                    putExtra(Intent.EXTRA_TEXT, trimmedLink)
                    clipData = ClipData.newPlainText("Configuration", trimmedLink)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(directIntent)
                started = true
            } catch (_: Exception) {
                // Attempt 2: Launch intent for V2Ray package with data attached
                try {
                    val launchIntent = packageManager.getLaunchIntentForPackage(V2RAY_PACKAGE)?.apply {
                        data = uri
                        putExtra(Intent.EXTRA_TEXT, trimmedLink)
                        clipData = ClipData.newPlainText("Configuration", trimmedLink)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (launchIntent != null) {
                        context.startActivity(launchIntent)
                        started = true
                    }
                } catch (_: Exception) {
                }
            }
        }

        if (started) {
            _uiState.update {
                it.copy(snackbarMessage = context.getString(R.string.opening_client))
            }
        } else {
            _uiState.update {
                it.copy(snackbarMessage = context.getString(R.string.no_compatible_client_installed))
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}

class ConfigViewModelFactory(private val repository: ConfigRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ConfigViewModel::class.java)) {
            return ConfigViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
