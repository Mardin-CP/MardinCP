package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TelegramProxyItem
import com.example.ui.components.CachedDataBanner
import com.example.ui.components.CountryBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.FilterSearchHeader
import com.example.ui.components.LinkCodeBox
import com.example.ui.components.ProtocolBadge
import com.example.ui.components.RecommendedBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.StatusFeedbackCard
import com.example.ui.viewmodel.ConfigUiState
import com.example.ui.viewmodel.ConfigViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelegramProxiesScreen(
    uiState: ConfigUiState,
    viewModel: ConfigViewModel,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState()
) {
    val context = LocalContext.current
    val pullToRefreshState = rememberPullToRefreshState()

    val filteredProxies = remember(
        uiState.configData.telegramProxies,
        uiState.searchQuery,
        uiState.selectedCountry,
        uiState.selectedProtocol
    ) {
        uiState.filteredProxies
    }

    val availableCountries = remember(uiState.configData.telegramProxies) {
        uiState.availableCountries
    }

    val availableProtocols = remember(uiState.configData.telegramProxies) {
        uiState.availableProtocols
    }

    PullToRefreshBox(
        isRefreshing = uiState.isRefreshing,
        onRefresh = { viewModel.refreshConfigs(isPullRefresh = true) },
        state = pullToRefreshState,
        modifier = modifier.fillMaxSize()
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Offline / Cache Info Banner
                CachedDataBanner(
                    isUsingCachedData = uiState.configData.isUsingCachedData,
                    lastUpdate = uiState.configData.lastUpdate,
                    onRefreshClick = { viewModel.refreshConfigs(showFullScreenLoading = false) }
                )
            }

            // Status feedback banner if updating/error
            if (uiState.feedbackMessage != null) {
                item {
                    StatusFeedbackCard(
                        feedbackMessage = uiState.feedbackMessage,
                        feedbackType = uiState.feedbackType
                    )
                }
            }

            // Search and Filters
            item {
                FilterSearchHeader(
                    searchQuery = uiState.searchQuery,
                    onSearchQueryChange = { viewModel.onSearchQueryChanged(it) },
                    countries = availableCountries,
                    selectedCountry = uiState.selectedCountry,
                    onCountrySelect = { viewModel.onCountrySelected(it) },
                    protocols = availableProtocols,
                    selectedProtocol = uiState.selectedProtocol,
                    onProtocolSelect = { viewModel.onProtocolSelected(it) }
                )
            }

            // Summary Info Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${stringResource(R.string.nav_proxies)} (${filteredProxies.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "MTProto / Socks",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (filteredProxies.isEmpty()) {
                item {
                    EmptyStateView(
                        message = stringResource(R.string.empty_proxies_title),
                        subtitle = stringResource(R.string.empty_state_subtitle),
                        onActionClick = { viewModel.refreshConfigs(showFullScreenLoading = true) },
                        actionLabel = stringResource(R.string.refresh_now)
                    )
                }
            } else {
                items(filteredProxies, key = { it.id }) { proxy ->
                    TelegramProxyCard(
                        proxy = proxy,
                        onOpenTelegram = { viewModel.openTelegramProxy(context, proxy.link) },
                        onCopy = { viewModel.copyToClipboard(context, "Telegram Proxy", proxy.link) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun TelegramProxyCard(
    proxy: TelegramProxyItem,
    onOpenTelegram: () -> Unit,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        onClick = onOpenTelegram,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = if (proxy.isRecommended) 3.dp else 2.dp,
            pressedElevation = 4.dp
        ),
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (proxy.isRecommended) {
                    Modifier.border(
                        1.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                        RoundedCornerShape(16.dp)
                    )
                } else Modifier
            )
            .testTag("telegram_proxy_card_${proxy.name.replace(" ", "_")}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            if (proxy.isRecommended) {
                RecommendedBadge(
                    modifier = Modifier
                        .padding(bottom = 10.dp)
                        .testTag("recommended_badge_${proxy.name.replace(" ", "_")}")
                )
            }

            // Header Row: Name and Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = proxy.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                StatusBadge(isAvailable = proxy.isAvailable)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Badges Row: Country, Protocol, Update Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CountryBadge(country = proxy.country, flag = proxy.countryFlag)
                ProtocolBadge(protocol = proxy.type)

                if (proxy.updateInfo.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Update,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = proxy.updateInfo,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Proxy Link Preview Box
            LinkCodeBox(link = proxy.link)

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenTelegram,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("open_telegram_button_${proxy.name.replace(" ", "_")}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.open_telegram),
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                OutlinedButton(
                    onClick = onCopy,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("copy_telegram_button_${proxy.name.replace(" ", "_")}")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.copy),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
