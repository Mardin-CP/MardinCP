package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.ConfigRepository
import com.example.ui.screens.MainScreen
import com.example.ui.theme.MardinTheme
import com.example.ui.viewmodel.ConfigUiState
import com.example.ui.viewmodel.ConfigViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Mardin", appName)
  }

  @Test
  fun `installations strings do not contain manual`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val title = context.getString(R.string.installations_title)
    val desc = context.getString(R.string.installations_desc)

    assertFalse("Title should not contain Manual", title.contains("Manual", ignoreCase = true))
    assertFalse("Description should not contain Manual", desc.contains("Manual", ignoreCase = true))
    assertEquals("Installations", title)
  }

  @Test
  fun `installations formatting produces formatted number`() {
    val stateEnglish = ConfigUiState(appLanguage = "en", installCount = 1250L)
    assertEquals("1,250", stateEnglish.formattedInstallCount)

    val statePersian = ConfigUiState(appLanguage = "fa", installCount = 1250L)
    // Persian locale format for 1250 is ۱٬۲۵۰
    assertTrue("Should contain Persian thousands separator or digits", statePersian.formattedInstallCount.contains("۱") || statePersian.formattedInstallCount.contains("1250"))
  }

  @Test
  fun `telegram deep link converts web links to native tg scheme`() {
    val repository = ConfigRepository(ApplicationProvider.getApplicationContext())
    val viewModel = ConfigViewModel(repository)

    val webLink = "https://t.me/proxy?server=1.2.3.4&port=443&secret=ee1122"
    val tgUri = viewModel.buildTelegramDeepLink(webLink)
    assertEquals("tg", tgUri.scheme)
    assertEquals("proxy", tgUri.host)
    assertEquals("server=1.2.3.4&port=443&secret=ee1122", tgUri.query)

    val socksLink = "https://t.me/socks?server=1.2.3.4&port=1080&user=user1&pass=pass1"
    val socksUri = viewModel.buildTelegramDeepLink(socksLink)
    assertEquals("tg", socksUri.scheme)
    assertEquals("socks", socksUri.host)
    assertEquals("server=1.2.3.4&port=1080&user=user1&pass=pass1", socksUri.query)

    val nativeTg = "tg://proxy?server=5.6.7.8&port=443&secret=dd3344"
    val nativeUri = viewModel.buildTelegramDeepLink(nativeTg)
    assertEquals("tg", nativeUri.scheme)
    assertEquals("proxy", nativeUri.host)
    assertEquals("server=5.6.7.8&port=443&secret=dd3344", nativeUri.query)
  }

  @Test
  fun `recommendation priority 2 - fallback to first item when none marked`() {
    val items = listOf("Proxy A", "Proxy B", "Proxy C")
    val explicitFlags = listOf(false, false, false)

    val results = ConfigRepository.applyRecommendationLogic(
      items = items,
      explicitFlags = explicitFlags
    ) { item, isRec -> item to isRec }

    assertEquals(3, results.size)
    assertTrue("First item must be recommended", results[0].second)
    assertFalse("Second item must NOT be recommended", results[1].second)
    assertFalse("Third item must NOT be recommended", results[2].second)
  }

  @Test
  fun `recommendation priority 1 - explicit single item recommendation`() {
    val items = listOf("Proxy A", "Proxy B", "Proxy C")
    val explicitFlags = listOf(false, true, false)

    val results = ConfigRepository.applyRecommendationLogic(
      items = items,
      explicitFlags = explicitFlags
    ) { item, isRec -> item to isRec }

    assertEquals(3, results.size)
    assertFalse("First item must NOT be recommended", results[0].second)
    assertTrue("Second item must be recommended", results[1].second)
    assertFalse("Third item must NOT be recommended", results[2].second)
  }

  @Test
  fun `recommendation priority 1 - multiple explicit recommendations`() {
    val items = listOf("Config 1", "Config 2", "Config 3", "Config 4")
    val explicitFlags = listOf(true, false, true, false)

    val results = ConfigRepository.applyRecommendationLogic(
      items = items,
      explicitFlags = explicitFlags
    ) { item, isRec -> item to isRec }

    assertEquals(4, results.size)
    assertTrue("First item must be recommended", results[0].second)
    assertFalse("Second item must NOT be recommended", results[1].second)
    assertTrue("Third item must be recommended", results[2].second)
    assertFalse("Fourth item must NOT be recommended", results[3].second)
  }

  @Test
  fun `recommendation on empty list returns empty list`() {
    val items = emptyList<String>()
    val explicitFlags = emptyList<Boolean>()

    val results = ConfigRepository.applyRecommendationLogic(
      items = items,
      explicitFlags = explicitFlags
    ) { item, isRec -> item to isRec }

    assertTrue("Result must be empty", results.isEmpty())
  }

  @Test
  fun `recommended strings match specification in english and persian`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // English string check
    val enConfig = android.content.res.Configuration(context.resources.configuration)
    enConfig.setLocale(java.util.Locale("en"))
    val enContext = context.createConfigurationContext(enConfig)
    val enString = enContext.getString(R.string.recommended_for_device)
    assertEquals("⭐ Recommended for your device", enString)

    // Persian string check
    val faConfig = android.content.res.Configuration(context.resources.configuration)
    faConfig.setLocale(java.util.Locale("fa"))
    val faContext = context.createConfigurationContext(faConfig)
    val faString = faContext.getString(R.string.recommended_for_device)
    assertEquals("⭐ پیشنهاد مناسب برای دستگاه شما", faString)
  }

  @Test
  fun `app update strings match specification in english and persian`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // English
    val enConfig = android.content.res.Configuration(context.resources.configuration)
    enConfig.setLocale(java.util.Locale.ENGLISH)
    val enContext = context.createConfigurationContext(enConfig)
    assertEquals("New Mardin update is available", enContext.getString(R.string.new_mardin_update_available))
    assertEquals("Update", enContext.getString(R.string.update))

    // Persian
    val faConfig = android.content.res.Configuration(context.resources.configuration)
    faConfig.setLocale(java.util.Locale.forLanguageTag("fa"))
    val faContext = context.createConfigurationContext(faConfig)
    assertEquals("نسخه جدید ماردین موجود است", faContext.getString(R.string.new_mardin_update_available))
    assertEquals("به‌روزرسانی", faContext.getString(R.string.update))
  }

  @Test
  fun `data update strings match specification in english and persian`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // English
    val enConfig = android.content.res.Configuration(context.resources.configuration)
    enConfig.setLocale(java.util.Locale.ENGLISH)
    val enContext = context.createConfigurationContext(enConfig)
    assertEquals("New Configs are available", enContext.getString(R.string.new_configs_available))
    assertEquals("New Proxies are available", enContext.getString(R.string.new_proxies_available))
    assertEquals("New Configs / Proxies are available", enContext.getString(R.string.new_configs_proxies_available))
    assertEquals("Update data", enContext.getString(R.string.update_data))
    assertEquals("No compatible application found", enContext.getString(R.string.no_compatible_application_found))

    // Persian
    val faConfig = android.content.res.Configuration(context.resources.configuration)
    faConfig.setLocale(java.util.Locale.forLanguageTag("fa"))
    val faContext = context.createConfigurationContext(faConfig)
    assertEquals("کانفیگ جدید موجود است", faContext.getString(R.string.new_configs_available))
    assertEquals("پروکسی جدید موجود است", faContext.getString(R.string.new_proxies_available))
    assertEquals("کانفیگ / پروکسی جدید موجود است", faContext.getString(R.string.new_configs_proxies_available))
    assertEquals("به‌روزرسانی داده‌ها", faContext.getString(R.string.update_data))
    assertEquals("برنامه سازگار پیدا نشد", faContext.getString(R.string.no_compatible_application_found))
  }

  @Test
  fun `openConfigWith shows no compatible client installed when V2Ray is not installed`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = ConfigRepository(context)
    val viewModel = ConfigViewModel(repository)

    // A vless:// config with no V2Ray installed in the test environment
    viewModel.openConfigWith(context, "vless://abcdef@1.2.3.4:443?security=reality#TestConfig")
    org.robolectric.shadows.ShadowLooper.idleMainLooper()

    val state = viewModel.uiState.value
    assertEquals(context.getString(R.string.no_compatible_client_installed), state.snackbarMessage)
  }

  @Test
  fun `dismiss notifications sets dismissed flags correctly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = ConfigRepository(context)
    val viewModel = ConfigViewModel(repository)

    viewModel.dismissAppUpdateNotification()
    assertTrue(viewModel.uiState.value.isAppUpdateDismissed)

    viewModel.dismissDataUpdateNotification()
    assertTrue(viewModel.uiState.value.isDataUpdateDismissed)
  }

  @Test
  fun `share mardin strings in english and persian match requirements`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // English
    val enConfig = android.content.res.Configuration(context.resources.configuration)
    enConfig.setLocale(java.util.Locale.ENGLISH)
    val enContext = context.createConfigurationContext(enConfig)
    assertEquals("Share Mardin", enContext.getString(R.string.share_mardin))
    assertEquals("Share the current Mardin APK with another device.", enContext.getString(R.string.share_mardin_desc))
    assertEquals("Unable to share Mardin APK.", enContext.getString(R.string.unable_share_apk))

    // Persian
    val faConfig = android.content.res.Configuration(context.resources.configuration)
    faConfig.setLocale(java.util.Locale.forLanguageTag("fa"))
    val faContext = context.createConfigurationContext(faConfig)
    assertEquals("اشتراک‌گذاری Mardin", faContext.getString(R.string.share_mardin))
    assertEquals("اشتراک‌گذاری فایل APK فعلی Mardin با دستگاه دیگر", faContext.getString(R.string.share_mardin_desc))
    assertEquals("امکان اشتراک‌گذاری فایل APK Mardin وجود ندارد.", faContext.getString(R.string.unable_share_apk))
  }

  @Test
  fun `shareApk handles inaccessible APK gracefully without crashing`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = ConfigRepository(context)
    val viewModel = ConfigViewModel(repository)

    // Ensure sourceDir points to non-existent file
    context.applicationInfo.sourceDir = "/non/existent/path/Mardin.apk"
    viewModel.shareApk(context)
    org.robolectric.shadows.ShadowLooper.idleMainLooper()

    val state = viewModel.uiState.value
    assertEquals(context.getString(R.string.unable_share_apk), state.snackbarMessage)
  }

  @Test
  fun `shareApk shares actual APK with ACTION_SEND and application package-archive MIME`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = ConfigRepository(context)
    val viewModel = ConfigViewModel(repository)

    // Create a dummy APK file at sourceDir
    val tempDir = java.io.File(context.cacheDir, "test_apk_source").apply { mkdirs() }
    val fakeApk = java.io.File(tempDir, "base.apk").apply {
      writeBytes(ByteArray(1024) { 0x50 }) // mock APK bytes (PK zip header etc)
    }
    context.applicationInfo.sourceDir = fakeApk.absolutePath

    viewModel.shareApk(context)
    val shadowApp = org.robolectric.Shadows.shadowOf(context as android.app.Application)

    // Verify chooser intent launched
    val startedIntent = requireNotNull(shadowApp.nextStartedActivity) {
      "Expected startedActivity but got null. snackbarMessage: ${viewModel.uiState.value.snackbarMessage}"
    }
    assertEquals(Intent.ACTION_CHOOSER, startedIntent.action)

    val rawSendIntent = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
      startedIntent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
    } else {
      @Suppress("DEPRECATION")
      startedIntent.getParcelableExtra(Intent.EXTRA_INTENT)
    }
    val sendIntent = requireNotNull(rawSendIntent)
    assertEquals(Intent.ACTION_SEND, sendIntent.action)
    assertEquals("application/vnd.android.package-archive", sendIntent.type)

    val streamUri = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
      sendIntent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
    } else {
      @Suppress("DEPRECATION")
      sendIntent.getParcelableExtra(Intent.EXTRA_STREAM)
    }
    assertNotNull(streamUri)
    assertTrue(streamUri.toString().startsWith("content://"))
    assertTrue(streamUri.toString().contains("Mardin"))
    assertTrue((sendIntent.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0)
  }
}
