# ProGuard rules for Mardin Proxy Configuration Manager
# Keep data models for Moshi JSON reflection/codegen
-keep class com.example.data.model.** { *; }
-keepclassmembers class com.example.data.model.** { *; }

# Keep Moshi annotations and adapters
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-dontwarn com.squareup.moshi.**
-keep class com.squareup.moshi.** { *; }
