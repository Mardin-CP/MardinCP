# Mardin

Lightweight and modern Proxy & Configuration Manager with Telegram proxies, configurations, and live remote configuration sync.

## Run Locally

**Prerequisites:** [Android Studio](https://developer.android.com/studio)

1. Open Android Studio.
2. Select **Open** and choose the directory containing this project.
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` if your build uses the Gemini API (see `.env.example` for an example).
5. Remove this line from the app's `build.gradle.kts` file if you are using your own release signing configuration: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device.

## Remote server configuration

Configure the public HTTP(S) server used for remote configuration and update metadata.

- `REMOTE_SERVER_BASE_URL` — server base URL.
- `REMOTE_CONFIG_PATH` — configuration JSON path.
- `REMOTE_STATS_PATH` — statistics JSON path.
- `REMOTE_UPDATE_PATH` — update metadata JSON path.

Example:

```text
https://your-domain.example/api/
```
